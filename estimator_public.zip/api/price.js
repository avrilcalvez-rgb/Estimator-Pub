export default async function handler(req, res) {
  try {
    if (req.method !== 'POST') return res.status(405).json({error:'Method not allowed'});
    const { w=0, h=0, product='accordion' } = req.body || {};
    const total = compute({ w: Number(w)||0, h: Number(h)||0, product });
    return res.status(200).json({ total });
  } catch (e) {
    return res.status(500).json({ error: 'Internal error' });
  }
}
function compute({ w, h, product }) {
  const areaSqft = Math.max((w*h)/144, 1);
  const rates = { accordion: 220, polycarbonate: 750, pleated: 180, honeycomb: 260 };
  const base = rates[product] || 200;
  const openingFee = 1000;
  const total = Math.round(areaSqft * base + openingFee);
  return total;
}